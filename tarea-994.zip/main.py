def BinDec(n):
    S=0
    i=0
    print('El binario',n,end=' ')
    while(n>=1):
        d=n%10;
        n=int(n/10);   #n=n//10
        S=S+d*pow(2,i);
        i=i+1 
        
    print('corresponde al número',S)
    
def DecBin(n):
    d=[]
    print('El número' ,n,end=' ')
    while(n>=1):
        d.append(n%2);
        n=int(n/2);   #n=n//2
        
    S=d[::-1]
    
    print('corresponde al binario',end='')
    [print(k,end='') for k in S]
    
BinDec(1101)
DecBin(13)